package cn.com.lgh.oracle;

import cn.com.lgh.operation.AbstractOptionLog;

public class OracleOptionLog extends AbstractOptionLog {

    @Override
    public String parseLog(String logContent,String format) {

        return "ORACLE";
    }
}
