package cn.com.lgh.kafkaDemo;


import cn.com.lgh.auditDemo.SQLProfilerUtils;
import com.alibaba.fastjson.JSONObject;
import com.audaque.lib.db.constants.DatabaseType;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.log4j.BasicConfigurator;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

/**
 * @author yuyufeng
 * @date 2018/5/10.
 */
public class UserKafkaConsumer {
    public static void main(String[] args) {
        BasicConfigurator.configure(); //自动快速地使用缺省Log4j环境。
        Properties props = new Properties();
        props.put("bootstrap.servers", "10.0.2.31:9092");
        props.put("group.id", "test-consumer-group");
        props.put("enable.auto.commit", "true");
        props.put("auto.commit.interval.ms", "1000");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        final KafkaConsumer<String, String> consumer = new KafkaConsumer<String,String>(props);
        consumer.subscribe(Arrays.asList("first"),new ConsumerRebalanceListener() {
            @Override
            public void onPartitionsRevoked(Collection<TopicPartition> collection) {
            }
            @Override
            public void onPartitionsAssigned(Collection<TopicPartition> collection) {
                //将偏移设置到最开始
                consumer.seekToBeginning(collection);
            }
        });
        String oldmes=null;
        Integer status=0;
        while (true) {
            ConsumerRecords<String, String> records = consumer.poll(100);
            String begainString=null;
            for (ConsumerRecord<String, String> record : records){
                begainString=record.value();
                System.out.println(begainString);
                if (begainString.indexOf("e_name")>0){
                    try {
                        JSONObject jsonObject= JSONObject.parseObject(begainString);
                       List list =  SQLProfilerUtils.getTableAndColumn(jsonObject.getString("sql"), DatabaseType.HWMPPDB);
                       if (list.isEmpty()){
                           System.out.println(jsonObject.getString("sql"));
                       }
                       System.out.println(JSONObject.toJSONString(list));
                    }catch (Exception e){
                        System.out.println(begainString);
                    }

                }


            }
        }
    }

}