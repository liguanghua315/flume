package cn.com.lgh.mysqldb;

import cn.com.lgh.operation.AbstractOptionLog;
import cn.com.lgh.operation.Record;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MysqlOptionLog extends AbstractOptionLog {
    //打印日志，便于测试方法的执行顺序
    private static final Logger logger = LoggerFactory.getLogger(MysqlOptionLog.class);
    private  String  sqlStatement=null ;
    private  boolean  multipleRows =false;//默认不跨行收集日志
    private  boolean isEnd=false;//是否结束日志收集
    private Record record=new Record();
    public String getSqlStatement() {
        return sqlStatement;
    }

    public void setSqlStatement(String sqlStatement) {
        this.sqlStatement = sqlStatement;
    }

    public boolean isMultipleRows() {
        return multipleRows;
    }

    public void setMultipleRows(boolean multipleRows) {
        this.multipleRows = multipleRows;
    }

    public boolean isEnd() {
        return isEnd;
    }

    public void setEnd(boolean end) {
        isEnd = end;
    }


    @Override
    public String parseLog(String logContent,String format) {
        if (logContent.indexOf("==>")>0){
           /* //单行sql收集
            record=null;
            String s1=logContent.split("==>")[0];
            record= getInfo(s1, format);
            record.setSql(logContent.split("Preparing:")[1]);
            sqlStatement= JSONObject.toJSONString(record);
            isEnd=true;//收集结束标识符
            logger.info("----------单行记录"+sqlStatement);*/
            if (logContent.indexOf("Preparing:")>0){
                //跨行sql日志收集前开始日志标识CONTEXT:
                multipleRows=true;//需要跨行收集表示符号开始
                record.cleanRecord();
                record= getInfo(record,logContent, format);
                sqlStatement=logContent.split("Preparing:")[1];
                logger.info("----------mysql跨行开始拼装行记录"+sqlStatement);
            }else  if (logContent.indexOf("Parameters:")>0){
                //跨行sql日志收集前结束日志标识 RETURN QUERY
                if (logContent.split("Parameters:").length>1 && StringUtils.isNotEmpty(logContent.split("Parameters:")[1].trim())&&!isEnd){
                    sqlStatement=getcanshu(sqlStatement,logContent);
                }
                record.setSql(sqlStatement);
                sqlStatement=JSONObject.toJSONString(record);
                record.cleanRecord();
                logger.info("----------跨行结束拼装行记录"+sqlStatement);
                multipleRows=false;//
                isEnd=true;//收集单行结束标识符
            }
        }
        if (isEnd){
            isEnd=false;//收集单行完毕，标识收集下一行日志
            return sqlStatement;
        }else{
            return null;
        }

    }
    /**
    * @Description:  获取参数数组
    * @Author:         LGH
    * @CreateDate:     2019/5/24 11:18
    */
    public static String  getcanshu(String result,String content) {

        if (content.indexOf("Parameters:") > 0 && StringUtils.isNotEmpty(content.split("Parameters:")[1].trim())) {
            String ge = content.split("Parameters:")[1];
            System.out.println(ge);
            String[] ar = ge.split("\\),");
            for (int i = 0; i < ar.length; i++) {
                String t = ar[i];
                if (StringUtils.isNotEmpty(t)&&!t.trim().equals("null")){
                    if (t.indexOf("String")>0||t.indexOf("Timestamp")>0){
                        ar[i] = "'"+ar[i].substring(0, t.lastIndexOf("(")).trim()+"'";
                    }else{
                        logger.info(t);
                        ar[i] = ar[i].substring(0, t.lastIndexOf("(")).trim();
                    }
                }else{
                    ar[i]=null;
                }

            }
            for (String t : ar) {
                System.out.println(t);
            }
            int count = 0;
            Pattern p = Pattern.compile("\\?");
            Matcher m = p.matcher(result);
            while (m.find()) {
                count++;
            }
            System.out.println(count);
            for (int i=0;i<count;i++){
                String t=ar[i];
                if (ar[i]==null){
                    result=result.replaceFirst("\\?,","");
                }else {
                    result=result.replaceFirst("\\?",ar[i]);
                }

            }
            logger.info("----------跨行结束拼装行记录"+result);
            return result;
        }else{
            return result;
        }
    }
}
