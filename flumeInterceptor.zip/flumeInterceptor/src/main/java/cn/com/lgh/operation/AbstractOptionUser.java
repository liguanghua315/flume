package cn.com.lgh.operation;

import org.apache.commons.lang.StringUtils;

public abstract class AbstractOptionUser {

    public static String  getValues(String data, String[] group,String[] valus){
        if (valus.length==1){
            return group[Integer.valueOf(valus[0])];
        }else{
            for (int i=Integer.valueOf(valus[0]);i<=Integer.valueOf(valus[1]);i++){
                if (data==null){
                    data=group[i];
                }else{
                    data=data+" "+group[i];
                }
            }
            return data;
        }
    }
    /**
     * @param content
     * @Description:    获取用户操作信息
     * @Author:         LGH
     * @CreateDate:     2019/3/20 11:07
     */
    public static Record getInfo(  Record record,String content,String format){
        /**
         * 华为mpp日志格式  现在使用格式 %m %c %d %p %a %x %n %e，为保证日志格式的变动，这里做日志随着格式动态截取
         * log_line_prefix = '%t '   # Special values:
         *      #   %u = user name
         *      #   %d = database name
         *      #   %r = remote host and port
         *      #   %h = remote host
         *      #   %p = PID
         *      #   %t = timestamp (no milliseconds)
         *      #   %m = timestamp with milliseconds
         *      #   %i = command tag
         *      #   %c = session id
         *      #   %l = session line number
         *      #   %s = session start timestamp
         *      #   %x = transaction id
         *      #   %q = stop here in non-session
         *      #        processes
         *      #   %% = '%'
         *      # e.g. '<%u%%%d> '
         */
       // Record record =new Record();
        String s1=content.split("STATEMENT:")[0];
        String[] group=s1.split(" ");
        String data=null;
        String session="";
        String db="";
        String pid="";
        String a_name="";
        String transactionId="";
        String n_name="";
        String e_name="";
        int md=0;
        if (StringUtils.isNotBlank(format)&&StringUtils.isNotBlank(content)){
            String [] formatList=format.split(" ");
            for (int f=0 ;f<formatList.length;f++){
                String fm=formatList[f];
                String[] bsf=fm.split("&");
                String fm1=bsf[0];
                String[] value=bsf[1].split("-");
                switch (fm1){
                    case "%m" : data=getValues(data,group,value)  ;break;
                    case "%c" :  session=getValues(session,group,value) ;break;
                    case "%d" :   db=getValues(db,group,value)  ;break;
                    case "%p" :  pid=getValues(pid,group,value);break;
                    case "%a" : a_name=getValues(a_name,group,value);break;
                    case "%x" :  transactionId=getValues(transactionId,group,value) ;break;
                    case "%n" :  n_name=getValues(n_name,group,value);break;
                    case "%e" : e_name=getValues(e_name,group,value)   ;break;
                }
            }
        }
        record.setData(data);
        record.setSession(session);
        record.setDb(db);
        record.setPid(pid);
        record.setA_name(a_name);
        record.setN_name(n_name);
        record.setTransactionId(transactionId);
        record.setE_name(e_name);

        return record;

    }
}
