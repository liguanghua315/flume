package cn.com.lgh.kafkaDemo;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

public class ProducerDemo {

    private final KafkaProducer<String, String> producer;

    public final static String TOPIC = "test5";

    private ProducerDemo() {
        Properties props = new Properties();
        props.put("bootstrap.servers", "192.168.0.20:9092,192.168.0.21:9092,192.168.0.22:9092");//xxx服务器ip
        props.put("acks", "all");//所有follower都响应了才认为消息提交成功，即"committed"
        props.put("retries", 0);//retries = MAX 无限重试，直到你意识到出现了问题:)
        props.put("batch.size", 16384);//producer将试图批处理消息记录，以减少请求次数.默认的批量处理消息字节数
        //batch.size当批量的数据大小达到设定值后，就会立即发送，不顾下面的linger.ms
        props.put("linger.ms", 1);//延迟1ms发送，这项设置将通过增加小的延迟来完成--即，不是立即发送一条记录，producer将会等待给定的延迟时间以允许其他消息记录发送，这些消息记录可以批量处理
        props.put("buffer.memory", 33554432);//producer可以用来缓存数据的内存大小。
        props.put("key.serializer",
                "org.apache.kafka.common.serialization.IntegerSerializer");
        props.put("value.serializer",
                "org.apache.kafka.common.serialization.StringSerializer");

        producer = new KafkaProducer<String, String>(props);
    }

    public void produce() {
        int messageNo = 1;
        final int COUNT = 5;

        while(messageNo < COUNT) {
            String key = String.valueOf(messageNo);
            String data = String.format("hello KafkaProducer message %s from hubo 06291018 ", key);

            try {
                producer.send(new ProducerRecord<String, String>(TOPIC, data));
            } catch (Exception e) {
                e.printStackTrace();
            }

            messageNo++;
        }

        producer.close();
    }

    public static void main(String[] args) {
       // new ProducerDemo().produce();
       String mes1="2019-03-18 16:46:26.633 CST 5c8f5ae2.975 postgres 140421195880192 gsql 0 cn_5001 00000 28846684 STATEMENT:  SELECT o_stat_collect_time as gauss_stat_output_time, o_total_blocks_read, o_total_blocks_hit, o_shared_buffer_hit_ratio FROM pmk.get_cluster_shared_buffer_stat(null, null);\n";
        String mes2="2019-03-18 16:46:26.716 CST 5c8f5ae2.936 postgres 140421720176384 gsql 0 cn_5001 00000 28846689 LOG:  Statistics in some tables or columns(pmk.pmk_snapshot.current_snapshot_time, pmk.pmk_snapshot.snapshot_id, pmk.pmk_snapshot_datanode_stat.snapshot_id, pmk.pmk_snapshot_coordinator_stat.snapshot_id) are not collected.";
        String mes3="2019-03-18 16:46:26.716 CST 5c8f5ae2.936 postgres 140421720176384 gsql 0 cn_5001 00000 28846689 HINT:  Do analyze for them in order to generate optimized plan.";
        String mes4="2019-03-18 09:17:26.237 CST 5c8ef1a6.986 postgres 140421359466240 gsql 0 cn_5001 00000 28813870 CONTEXT:  SQL statement \"WITH snap AS\n" +
                "\t\t     (SELECT snapshot_id\n" +
                "\t\t\t\t    , current_snapshot_time AS pmk_curr_collect_start_time\n" +
                "\t\t\t     FROM pmk.pmk_snapshot\n" +
                "\t\t\t    WHERE current_snapshot_time\t\tBETWEEN i_start_pmk_time AND i_end_pmk_time\n" +
                "\t\t\t ), cpu_stat AS\n" +
                "\t\t\t (SELECT s.snapshot_id\n" +
                "\t\t\t\t\t, s.pmk_curr_collect_start_time\n" +
                "\t\t\t\t\t, dns.node_name\n" +
                "\t\t\t\t\t, dns.node_host\n" +
                "\t\t\t\t\t, (dns.busy_time_delta * 10)AS host_cpu_busy_time\n" +
                "\t\t\t\t\t, (dns.idle_time_delta * 10)AS host_cpu_idle_time\n" +
                "\t\t\t\t\t, (dns.iowait_time_delta * 10)AS host_cpu_iowait_time\n" +
                "\t\t\t\t\t, (dns.db_cpu_time_delta * 10)AS mppdb_cpu_time\n" +
                "\t\t\t\t FROM pmk.pmk_snapshot_datanode_stat dns, snap s\n" +
                "\t\t\t\tWHERE dns.snapshot_id\t\t\t= s.snapshot_id\n" +
                "\t\t\t\tUNION ALL\n" +
                "\t\t\t   SELECT s.snapshot_id\n" +
                "\t\t\t\t\t, s.pmk_curr_collect_start_time\n" +
                "\t\t\t\t\t, dns.node_name\n" +
                "\t\t\t\t\t, dns.node_host\n" +
                "\t\t\t\t\t, (dns.busy_time_delta * 10)AS host_cpu_busy_time\n" +
                "\t\t\t\t\t, (dns.idle_time_delta * 10)AS host_cpu_idle_time\n" +
                "\t\t\t\t\t, (dns.iowait_time_delta * 10)AS host_cpu_iowait_time\n" +
                "\t\t\t\t\t, (dns.db_cpu_time_delta * 10)AS mppdb_cpu_time\n" +
                "\t\t\t\t FROM pmk.pmk_snapshot_coordinator_stat dns, snap s\n" +
                "\t\t\t\tWHERE dns.snapshot_id\t\t\t= s.snapshot_id\n" +
                "\t\t\t ), host_cpu_stat AS \n" +
                "\t\t\t(SELECT pmk_curr_collect_start_time::timestamp AS stat_collect_time\n" +
                "\t\t\t\t   , node_host\n" +
                "\t\t\t\t   , host_cpu_busy_time\n" +
                "\t\t\t\t   , host_cpu_idle_time\n" +
                "\t\t\t\t   , host_cpu_iowait_time\n" +
                "\t\t\t\t   , (host_cpu_busy_time+host_cpu_idle_time+host_cpu_iowait_time)::numeric AS host_cpu_total_time\n" +
                "\t\t\t\tFROM (SELECT pmk_curr_collect_start_time\n" +
                "\t\t\t\t\t\t\t, node_host\n" +
                "\t\t\t\t\t\t\t, host_cpu_busy_time\n" +
                "\t\t\t\t\t\t\t, host_cpu_idle_time\n" +
                "\t\t\t\t\t\t\t, host_cpu_iowait_time\n" +
                "\t\t\t\t\t\t\t, rank()OVER (PARTITION BY snapshot_id, node_host \n" +
                "\t\t\t\t\t\t\t\t\t\t\t   ORDER BY host_cpu_busy_time DESC, node_name)AS node_cpu_busy_order\n" +
                "\t\t\t\t\t\t FROM cpu_stat\n" +
                "\t\t\t\t\t )WHERE node_cpu_busy_order = 1\n" +
                "\t\t\t), host_cpu_stat_summary AS \n" +
                "\t\t\t(SELECT stat_collect_time\n" +
                "\t\t\t\t   , AVG(host_cpu_busy_time)::numeric(21, 3)AS avg_host_cpu_busy_time\n" +
                "\t\t\t\t   , AVG(host_cpu_total_time)::numeric(21, 3)AS avg_host_cpu_total_time\n" +
                "\t\t\t\t   , SUM(host_cpu_busy_time)::numeric(21, 3)AS tot_host_cpu_busy_time\n" +
                "\t\t\t\t   , SUM(host_cpu_total_time)::numeric(21, 3)AS tot_host_cpu_total_time\n" +
                "\t\t\t\tFROM host_cpu_stat\n" +
                "\t\t\t   GROUP BY stat_collect_time\n" +
                "\t\t\t), mppdb_cpu_stat0 AS\n" +
                "\t\t\t(SELECT pmk_curr_collect_start_time::timestamp AS stat_collect_time\n" +
                "\t\t\t\t   , node_name\n" +
                "\t\t\t\t   , mppdb_cpu_time\n" +
                "\t\t\t\t   , host_cpu_busy_time\n" +
                "\t\t\t\t   , (host_cpu_busy_time+host_cpu_idle_time+host_cpu_iowait_time)::numeric AS host_cpu_total_time\n" +
                "\t\t\t\tFROM cpu_stat\n" +
                "\t\t\t), mppdb_cpu_stat AS\n" +
                "\t\t\t(SELECT stat_collect_time\n" +
                "\t\t\t\t   , node_name\n" +
                "\t\t\t\t   , mppdb_cpu_time\n" +
                "\t\t\t\t   , ((mppdb_cpu_time * 100.0)/ NULLIF(host_cpu_busy_time, 0))::numeric(5, 2)AS mppdb_cpu_time_perc_wrt_busy_time\n" +
                "\t\t\t\t   , ((mppdb_cpu_time * 100.0)/ NULLIF(host_cpu_total_time, 0))::numeric(5, 2)AS mppdb_cpu_time_perc_wrt_total_time\n" +
                "\t\t\t\tFROM mppdb_cpu_stat0\n" +
                "\t\t\t), mppdb_cpu_stat_summary AS\n" +
                "\t\t\t(SELECT stat_collect_time\n" +
                "\t\t\t\t   , AVG(mppdb_cpu_time)::numeric(21, 3)AS avg_mppdb_cpu_time\n" +
                "\t\t\t\t   , SUM(mppdb_cpu_time)::numeric(21, 3)AS tot_mppdb_cpu_time\n" +
                "\t\t\t\t   , MIN(mppdb_cpu_time_perc_wrt_busy_time)::numeric(5, 2)AS min_mppdb_cpu_time_perc_wrt_busy_time\n" +
                "\t\t\t\t   , MAX(mppdb_cpu_time_perc_wrt_busy_time)::numeric(5, 2)AS max_mppdb_cpu_time_perc_wrt_busy_time\n" +
                "\t\t\t\t   , MIN(mppdb_cpu_time_perc_wrt_total_time)::numeric(5, 2)AS min_mppdb_cpu_time_perc_wrt_total_time\n" +
                "\t\t\t\t   , MAX(mppdb_cpu_time_perc_wrt_total_time)::numeric(5, 2)AS max_mppdb_cpu_time_perc_wrt_total_time\n" +
                "\t\t\t\tFROM mppdb_cpu_stat\n" +
                "\t\t\t   GROUP BY stat_collect_time\n" +
                "\t\t\t)SELECT mcs.stat_collect_time\n" +
                "\t\t\t , mcs.avg_mppdb_cpu_time\n" +
                "\t\t\t , hcs.avg_host_cpu_busy_time\n" +
                "\t\t\t , hcs.avg_host_cpu_total_time\n" +
                "\t\t\t , CASE WHEN mcs.tot_mppdb_cpu_time < hcs.tot_host_cpu_busy_time\n" +
                "\t\t\t\t\t\t THEN ((mcs.tot_mppdb_cpu_time * 100.0)/ NULLIF(hcs.tot_host_cpu_busy_time, 0))::numeric(5, 2)ELSE 100.00\n" +
                "\t\t\t\tEND AS mppdb_cpu_time_perc_wrt_busy_time\n" +
                "\t\t\t , CASE WHEN mcs.tot_mppdb_cpu_time < hcs.tot_host_cpu_total_time\n" +
                "\t\t\t\t\t\t THEN ((mcs.tot_mppdb_cpu_time * 100.0)/ NULLIF(hcs.tot_host_cpu_total_time, 0))::numeric(5, 2)ELSE 100.00\n" +
                "\t\t\t\tEND AS mppdb_cpu_time_perc_wrt_total_time\n" +
                "\t\t\t , mcs.min_mppdb_cpu_time_perc_wrt_busy_time\n" +
                "\t\t\t , mcs.max_mppdb_cpu_time_perc_wrt_busy_time\n" +
                "\t\t\t , mcs.min_mppdb_cpu_time_perc_wrt_total_time\n" +
                "\t\t\t , mcs.max_mppdb_cpu_time_perc_wrt_total_time\n" +
                "\t\t  FROM mppdb_cpu_stat_summary mcs\n" +
                "\t\t     , host_cpu_stat_summary hcs\n" +
                "\t\t WHERE mcs.stat_collect_time\t= hcs.stat_collect_time\n" +
                "\t\t ORDER BY mcs.stat_collect_time\"\n" +
                "\tPL/pgSQL function pmk.get_cluster_mppdb_cpu_stat(timestamp with time zone,timestamp with time zone) line 31 at RETURN QUERY";

        if (mes1.indexOf("STATEMENT:")>0){
            String s1=mes1.split("STATEMENT:")[0];
            String[] group=s1.split(" ");
            String data=null;
            String session="";
            String db="";
            String pid="";
            String a_name="";
            String transactionId="";
            String n_name="";
            String e_name="";
            for (int i=0;i<group.length;i++){
                if (i<3){
                    if (data==null){
                        data=group[i];
                    }else {
                        data=data+" "+group[i];
                    }
                }
                if (i==3){
                    session=group[i] ;
                }else  if (i==4){
                    db=group[i] ;
                }else  if (i==5){
                    pid=group[i] ;
                }else  if (i==6){
                    a_name=group[i] ;
                }else  if (i==7){
                    transactionId=group[i] ;
                }else  if (i==8){
                    n_name=group[i] ;
                }else  if (i==9){
                    e_name=group[i] ;
                }

            }
            System.out.println(data);
            System.out.println(session);
            System.out.println(db);
            System.out.println(pid);
            System.out.println(a_name);
            System.out.println(n_name);
            System.out.println(transactionId);
            System.out.println(e_name);
            System.out.println(mes1.split("STATEMENT:")[1]);


       }
        if (mes4.indexOf("SQL statement")>0){
            System.out.println(((mes4.split("SQL statement")[1]).split("PL/pgSQL"))[0]);
        }
        System.out.println(mes1.split("STATEMENT:"));
    }
}
