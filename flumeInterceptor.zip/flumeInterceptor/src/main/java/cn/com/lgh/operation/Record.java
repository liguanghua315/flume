package cn.com.lgh.operation;

public class Record {
    private String data;//日期
    private String session;//
    private String db;//数据库
    private String pid;//进程id
    private String a_name;
    private String transactionId;
    private String n_name;
    private String e_name;
    private String sql;

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    public Record() {
    }

    public void cleanRecord() {
        this.data = "";
        this.session =  "";
        this.db =  "";
        this.pid =  "";
        this.a_name =  "";
        this.transactionId =  "";
        this.n_name =  "";
        this.e_name = "";
        this.sql =  "";
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getSession() {
        return session;
    }

    public void setSession(String session) {
        this.session = session;
    }

    public String getDb() {
        return db;
    }

    public void setDb(String db) {
        this.db = db;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getA_name() {
        return a_name;
    }

    public void setA_name(String a_name) {
        this.a_name = a_name;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getN_name() {
        return n_name;
    }

    public void setN_name(String n_name) {
        this.n_name = n_name;
    }

    public String getE_name() {
        return e_name;
    }

    public void setE_name(String e_name) {
        this.e_name = e_name;
    }
}
