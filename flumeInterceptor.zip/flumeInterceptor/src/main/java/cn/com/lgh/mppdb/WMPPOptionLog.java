package cn.com.lgh.mppdb;

import cn.com.lgh.operation.AbstractOptionLog;
import cn.com.lgh.operation.Record;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class WMPPOptionLog extends AbstractOptionLog {
    //打印日志，便于测试方法的执行顺序
    private static final Logger logger = LoggerFactory.getLogger(WMPPOptionLog.class);
    private  String  sqlStatement=null ;
    private  boolean  multipleRows =false;//默认不跨行收集日志
    private  boolean isEnd=false;//是否结束日志收集
    private  Record record=new Record();
    public String getSqlStatement() {
        return sqlStatement;
    }

    public void setSqlStatement(String sqlStatement) {
        this.sqlStatement = sqlStatement;
    }

    public boolean isMultipleRows() {
        return multipleRows;
    }

    public void setMultipleRows(boolean multipleRows) {
        this.multipleRows = multipleRows;
    }

    public boolean isEnd() {
        return isEnd;
    }

    public void setEnd(boolean end) {
        isEnd = end;
    }

    @Override
    public String parseLog(String begainString,String format) {
        //根据日志格式拆分日志，有的需要跨行收集，有的需要单行拆分，有的不需要拆分，需要拼接的

        if (begainString.indexOf("STATEMENT:")>0){
            //单行sql收集
            record.cleanRecord();
            String s1=begainString.split("STATEMENT:")[0];
             record= getInfo(record,s1, format);
            record.setSql(sql1(begainString));
            sqlStatement= JSONObject.toJSONString(record);
            isEnd=true;//收集结束标识符
            logger.info("----------单行记录"+sqlStatement);
        }else   if (begainString.indexOf("CONTEXT:")>0){
            //跨行sql日志收集前开始日志标识CONTEXT:
            multipleRows=true;//需要跨行收集表示符号开始
            record.cleanRecord();
            record= getInfo(record,begainString, format);
            sqlStatement=sql4(begainString);
            logger.info("----------跨行开始拼装行记录"+sqlStatement);
        }else  if (begainString.indexOf("RETURN QUERY")>0){
            //跨行sql日志收集前结束日志标识 RETURN QUERY
            record.setSql(sqlStatement);
            sqlStatement=JSONObject.toJSONString(record);
            record.cleanRecord();
            logger.info("----------跨行结束拼装行记录"+sqlStatement);
            multipleRows=false;//
            isEnd=true;//收集单行结束标识符
        }else{
            //是否跨行追加文本
            sqlStatement=sql5(sqlStatement,begainString,multipleRows);
        }
        if (isEnd){
            isEnd=false;//收集单行完毕，标识收集下一行日志
            return sqlStatement;
        }else{
            return null;
        }
    }


    /**
     * @param
    * @Description:   获取单行sql
    * @Author:         LGH
    * @CreateDate:     2019/3/21 11:18
    */
    public static String sql1(String content){
        return content.split("STATEMENT:")[1];
    }

    public static String sql4(String content){
        if (content.indexOf("SQL statement")>0){
            content=content.split("SQL statement")[1];
        }
        return  content;
    }

    /**
     * @param
    * @Description:    跨行拼装sql数据
    * @Author:         LGH
    * @CreateDate:     2019/3/21 11:18
    */
    public static String sql5(String oldmes,String content,boolean multipleRows){
        if (multipleRows){
            return oldmes+" "+content;
        }else{
            return content;
        }
    }
}
