package cn.com.lgh.auditDemo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.druid.sql.ast.SQLStatement;
import com.alibaba.druid.sql.ast.statement.SQLSelectItem;
import com.alibaba.druid.sql.ast.statement.SQLSelectQueryBlock;
import com.alibaba.druid.sql.ast.statement.SQLSelectStatement;
import com.alibaba.druid.sql.dialect.db2.parser.DB2StatementParser;
import com.alibaba.druid.sql.dialect.db2.visitor.DB2SchemaStatVisitor;
import com.alibaba.druid.sql.dialect.hive.parser.HiveStatementParser;
import com.alibaba.druid.sql.dialect.hive.visitor.HiveSchemaStatVisitor;
import com.alibaba.druid.sql.dialect.mysql.ast.statement.MySqlSelectQueryBlock;
import com.alibaba.druid.sql.dialect.mysql.parser.MySqlStatementParser;
import com.alibaba.druid.sql.dialect.mysql.visitor.MySqlSchemaStatVisitor;
import com.alibaba.druid.sql.dialect.oracle.parser.OracleStatementParser;
import com.alibaba.druid.sql.dialect.oracle.visitor.OracleSchemaStatVisitor;
import com.alibaba.druid.sql.dialect.postgresql.ast.stmt.PGSelectQueryBlock;
import com.alibaba.druid.sql.dialect.postgresql.ast.stmt.PGSelectStatement;
import com.alibaba.druid.sql.dialect.postgresql.parser.PGSQLStatementParser;
import com.alibaba.druid.sql.dialect.postgresql.visitor.PGSchemaStatVisitor;
import com.alibaba.druid.sql.dialect.sqlserver.parser.SQLServerStatementParser;
import com.alibaba.druid.sql.dialect.sqlserver.visitor.SQLServerSchemaStatVisitor;
import com.alibaba.druid.sql.parser.SQLParserUtils;
import com.alibaba.druid.sql.parser.SQLStatementParser;
import com.alibaba.druid.sql.parser.Token;
import com.alibaba.druid.sql.visitor.SchemaStatVisitor;
import com.alibaba.druid.stat.TableStat;
import com.alibaba.druid.stat.TableStat.Column;
import com.alibaba.druid.stat.TableStat.Name;
import com.alibaba.druid.util.JdbcConstants;
import com.alibaba.fastjson.JSONObject;
import com.audaque.component.core.exception.AudaqueException;
import com.audaque.lib.db.constants.DatabaseType;

/**
 * @Description:  SQL解析工具类
 * @Title:  SQLProfilerUtils.java
 * @Package com.audaque.web.action
 * @author: huafu.su
 * @date: 2019年3月18日 上午10:59:56
 */
public class SQLProfilerUtils {

	public static List<AuditTable> getTableAndColumn(String sql, DatabaseType type){
		String dbType = getDruidDatabaseType(type);
		SQLStatementParser sqlParser = SQLParserUtils.createSQLStatementParser(sql, dbType);
		Token token = sqlParser.getLexer().token();
		SQLStatement statement = null;//sqlParser.parseStatement();
		if(JdbcConstants.MYSQL.equals(dbType)){
			MySqlStatementParser mysqlParser = (MySqlStatementParser)sqlParser;
			statement = mysqlParser.parseStatement();
			MySqlSchemaStatVisitor mysqlvisitor = new MySqlSchemaStatVisitor();
			if(statement instanceof SQLSelectStatement){
				SQLSelectStatement mysqlstatement = (SQLSelectStatement)statement;
				mysqlstatement.accept(mysqlvisitor);
				MySqlSelectQueryBlock mysqlBlock = (MySqlSelectQueryBlock)mysqlstatement.getSelect().getQuery();
				List<SQLSelectItem> selectItems = mysqlBlock.getSelectList();
				return getTableAndColumnForSelect(selectItems, mysqlvisitor, Token.SELECT);
			}else{
				statement.accept(mysqlvisitor);
				return getTableAndColumn(null,mysqlvisitor,token);
			}
		}else if(JdbcConstants.ORACLE.equals(dbType)){
			OracleStatementParser oracleParser = (OracleStatementParser)sqlParser;
			statement = oracleParser.parseStatement();
			OracleSchemaStatVisitor visitor = new OracleSchemaStatVisitor();
			if(statement instanceof SQLSelectStatement){
				SQLSelectStatement sqlstatement = (SQLSelectStatement)statement;
				sqlstatement.accept(visitor);
				SQLSelectQueryBlock mysqlBlock = (SQLSelectQueryBlock)sqlstatement.getSelect().getQuery();
				List<SQLSelectItem> selectItems = mysqlBlock.getSelectList();
				return getTableAndColumnForSelect(selectItems, visitor, Token.SELECT);
			}else{
				statement.accept(visitor);
				return getTableAndColumn(null,visitor,token);
			}
		}else if(JdbcConstants.SQL_SERVER.equals(dbType)){
			SQLServerStatementParser sqlServerParser = (SQLServerStatementParser)sqlParser;
			statement = sqlServerParser.parseStatement();
			SQLServerSchemaStatVisitor visitor = new SQLServerSchemaStatVisitor();
			if(statement instanceof SQLSelectStatement){
				SQLSelectStatement sqlstatement = (SQLSelectStatement)statement;
				sqlstatement.accept(visitor);
				SQLSelectQueryBlock mysqlBlock = (SQLSelectQueryBlock)sqlstatement.getSelect().getQuery();
				List<SQLSelectItem> selectItems = mysqlBlock.getSelectList();
				return getTableAndColumnForSelect(selectItems, visitor, Token.SELECT);
			}else{
				statement.accept(visitor);
				return getTableAndColumn(null,visitor,token);
			}
		}else if(JdbcConstants.DB2.equals(dbType)){
			DB2StatementParser db2Parser = (DB2StatementParser)sqlParser;
			statement = db2Parser.parseStatement();
			DB2SchemaStatVisitor visitor = new DB2SchemaStatVisitor();
			if(statement instanceof SQLSelectStatement){
				SQLSelectStatement sqlstatement = (SQLSelectStatement)statement;
				sqlstatement.accept(visitor);
				SQLSelectQueryBlock mysqlBlock = (SQLSelectQueryBlock)sqlstatement.getSelect().getQuery();
				List<SQLSelectItem> selectItems = mysqlBlock.getSelectList();
				return getTableAndColumnForSelect(selectItems, visitor, Token.SELECT);
			}else{
				statement.accept(visitor);
				return getTableAndColumn(null,visitor,token);
			}
		}else if(JdbcConstants.POSTGRESQL.equals(dbType)){
			PGSQLStatementParser pgParser = (PGSQLStatementParser)sqlParser;
			statement = pgParser.parseStatement();
			PGSchemaStatVisitor pgvisitor = new PGSchemaStatVisitor();
			if(statement instanceof PGSelectStatement){
				PGSelectStatement pgstatement = (PGSelectStatement)statement;
				pgstatement.accept(pgvisitor);
				PGSelectQueryBlock pgBlock = (PGSelectQueryBlock)pgstatement.getSelect().getQuery();
				List<SQLSelectItem> selectItems = pgBlock.getSelectList();
				return getTableAndColumnForSelect(selectItems, pgvisitor, Token.SELECT);
			}else{
				statement.accept(pgvisitor);
				return getTableAndColumn(null,pgvisitor,token);
			}
		}else if(JdbcConstants.HIVE.equals(dbType)){
			HiveStatementParser hiveParser = (HiveStatementParser)sqlParser;
			statement = hiveParser.parseStatement();
			HiveSchemaStatVisitor visitor = new HiveSchemaStatVisitor();
			if(statement instanceof SQLSelectStatement){
				SQLSelectStatement sqlstatement = (SQLSelectStatement)statement;
				sqlstatement.accept(visitor);
				SQLSelectQueryBlock mysqlBlock = (SQLSelectQueryBlock)sqlstatement.getSelect().getQuery();
				List<SQLSelectItem> selectItems = mysqlBlock.getSelectList();
				return getTableAndColumnForSelect(selectItems, visitor, Token.SELECT);
			}else{
				statement.accept(visitor);
				return getTableAndColumn(null,visitor,token);
			}
		}else{
			throw new AudaqueException("不支持的数据库："+type.getName());
		}
	}

	/**
	 * @Description: 组装新增、更新、删除SQL的表与列
	 * @Title: getTableAndColumn
	 * @param visitor
	 * @return List<AuditTable>
	 * @author: huafu.su
	 */
	private static List<AuditTable> getTableAndColumn(Map<String, AuditColumn> columnMap, SchemaStatVisitor visitor, Token token){
		List<AuditTable> list = new ArrayList<>();
		Map<String, AuditTable> tableMap = new HashMap<>();
		if(columnMap == null)
			columnMap = new HashMap<>();
		Map<Name, TableStat> nameMap = visitor.getTables();
		if(nameMap != null){
			for (Name name : nameMap.keySet()) {
				AuditTable auditTable = new AuditTable();
				String table = name.getName();
				if(table.indexOf(".") != -1){
					String[] str = table.split("\\.");
					auditTable.setFullName(table);
					auditTable.setSchema(str[0]);
					auditTable.setTableName(str[1]);
				}else{
					auditTable.setTableName(table);
				}
				auditTable.setSqlType(token.name);
				tableMap.put(table, auditTable);
			}
		}
		Collection<Column> columns = visitor.getColumns();
		if(columns != null){
			for (Column column : columns) {
				AuditTable auditTable = null;
				if(tableMap.containsKey(column.getTable())){
					auditTable = tableMap.get(column.getTable());
				}else{
					auditTable = new AuditTable();
					String table = column.getTable();
					if(table.indexOf(".") != -1){
						String[] str = table.split("\\.");
						auditTable.setFullName(table);
						auditTable.setSchema(str[0]);
						auditTable.setTableName(str[1]);
					}else{
						auditTable.setTableName(table);
					}
					auditTable.setSqlType(token.name);
					tableMap.put(table, auditTable);
				}
				if("*".equals(column.getName())){
					auditTable.setAllColumn(true);
				}
				if(columnMap.containsKey(column.getName())){//如果列别名存在了，取出放入表中；清除列缓存
					AuditColumn auditColumn = columnMap.get(column.getName());
					auditColumn.setTable(column.getTable());
					auditTable.addAuditColumn(auditColumn);
					columnMap.remove(column.getName());
				}else{
					AuditColumn auditColumn = new AuditColumn(column.getName(),column.getName(),column.getFullName());
					auditColumn.setTable(column.getTable());
					auditTable.addAuditColumn(auditColumn);
				}
			}
		}
		AuditTable unknown = tableMap.get("UNKNOWN");
		for (String key : tableMap.keySet()) {
			AuditTable table = tableMap.get(key);
			if(!columnMap.isEmpty()){//缓存列没有找到对应表的给所有的表加上
				for (AuditColumn column : columnMap.values()) {
					table.addAuditColumn(column);
				}
			}
			if(unknown != null && !unknown.equals(table)){//如果有不确认的列,给所有表加上
				for (AuditColumn column : unknown.getColumns()) {
					table.addAuditColumn(column);
				}
				list.add(table);
			}else{
				list.add(table);
			}
		}
		return list;
	}

	/**
	 * @Description: 组装查询SQL的表与列
	 * @Title: getTableAndColumnForSelect
	 * @param selectItems
	 * @param columns
	 * @return List<AuditTable>
	 * @author: huafu.su
	 */
	private static List<AuditTable> getTableAndColumnForSelect(List<SQLSelectItem> selectItems,
															   SchemaStatVisitor visitor, Token token){
		Map<String, AuditColumn> columnMap = new HashMap<>();
		if(selectItems != null){//Visitor列是优先取SQL中的别名；业务处理是要用表的列名，按别名先缓存后面处理
			for (SQLSelectItem item : selectItems) {
				columnMap.put(item.getAlias(), new AuditColumn(item.getAlias(),item.getExpr().toString(),null));
			}
		}
		return getTableAndColumn(columnMap, visitor, token);
	}
	public static void main(String[] args) {
		String sql1 = "WITH snap AS (SELECT snapshot_id " + ", current_snapshot_time AS pmk_curr_collect_start_time "
				+ " FROM pmk.pmk_snapshot"
				+ " WHERE current_snapshot_time		BETWEEN i_start_pmk_time AND i_end_pmk_time" + " )SELECT node_type"
				+ " , node_name" + " , node_host" + " , pmk_curr_collect_start_time::timestamp AS stat_collect_time "
				+ " , number_of_files" + " , physical_reads" + " , physical_writes" + " , read_time" + " , write_time"
				+ " , (physical_reads * 1000000.0 / NULLIF(read_time, 0))::numeric(20,2)AS avg_read_per_sec"
				+ " , (read_time * 1.0 / NULLIF(physical_reads, 0))::numeric(20,3)AS avg_read_time"
				+ " , (physical_writes * 1000000.0 / NULLIF(write_time, 0))::numeric(20,2)AS avg_write_per_sec"
				+ " , (write_time * 1.0 / NULLIF(physical_writes, 0))::numeric(20,3)AS avg_write_time"
				+ " FROM (SELECT 'D'::char(1)AS node_type" + "		  , node_name" + "        , node_host"
				+ "	  , s.pmk_curr_collect_start_time " + "	  , number_of_files"
				+ "	  , physical_reads_delta AS physical_reads" + "	  , physical_writes_delta AS physical_writes"
				+ "	  , read_time_delta AS read_time" + "	  , write_time_delta AS write_time"
				+ "   FROM pmk.pmk_snapshot_datanode_stat dns, snap s"
				+ "  WHERE dns.snapshot_id			= s.snapshot_id" + "  UNION ALL"
				+ " SELECT 'C'::char(1)AS node_type" + "	  , node_name" + "       , node_host"
				+ "	  , s.pmk_curr_collect_start_time " + "	  , number_of_files"
				+ "	  , physical_reads_delta AS physical_reads" + "	  , physical_writes_delta AS physical_writes"
				+ "	  , read_time_delta AS read_time" + "	  , write_time_delta AS write_time"
				+ "   FROM pmk.pmk_snapshot_coordinator_stat dns, snap s"
				+ "  WHERE dns.snapshot_id			= s.snapshot_id"
				+ "  )ORDER BY node_type, node_name, stat_collect_time";
//		String sql ="DELETE FROM adqm_data_source_copy WHERE (DATA_SOURCE_ID='2')";
//		String sql ="UPDATE adqm_data_source_copy SET ORG_DEPT_ID='4', SYS_NAME='4', DUTY_PERSON='4', SOURCE_NAME='4', SOURCE_TYPE_CODE='4', DATABASE_TYPE='4', HOST='4', PORT='4', DB_SERVICE_NAME='4', USER_NAME='24', PASSWORD='224', DESCRIPTION='24', STATUS='4' WHERE (DATA_SOURCE_ID='2')";
//		String sql ="INSERT INTO adqm_data_source_copy (DATA_SOURCE_ID, ORG_DEPT_ID, SYS_NAME, DUTY_PERSON, SOURCE_NAME, SOURCE_TYPE_CODE, DATABASE_TYPE, HOST, PORT, DB_SERVICE_NAME, USER_NAME, PASSWORD, DB_CON_URL, DESCRIPTION, DB_INSTANCE_NAME, SCHEMA_NAME) VALUES ('2', '1', '2', '2', '2', '2', '2', '2', '2', '2', '2', '22', '2', '2', '2', '2');";
//		String sql = "select * from adqm_data_source_copy";
		String sql = "select * from adqm_data_source_copy";
		List<AuditTable> list = SQLProfilerUtils.getTableAndColumn(sql1, DatabaseType.HWMPPDB);
		for (AuditTable auditTable : list) {
			System.out.println(JSONObject.toJSONString(auditTable));
		}
	}
	/**
	 * @Description: 将华傲数据库类型转换为Druid工具包的数据库类型
	 * @Title: getDruidDatabaseType
	 * @param type
	 * @return String
	 * @author: huafu.su
	 */
	@SuppressWarnings("incomplete-switch")
	private static String getDruidDatabaseType(DatabaseType type){
		String databaseType = JdbcConstants.MYSQL;
		switch (type) {
			case Oracle:
				databaseType = JdbcConstants.ORACLE;
				break;
			case SQLServer:
			case SQLServer2000:
				databaseType = JdbcConstants.SQL_SERVER;
				break;
			case MySQL:
				databaseType = JdbcConstants.MYSQL;
				break;
			case DB2:
				databaseType = JdbcConstants.DB2;
				break;
			case PostgreSQL:
			case GreenPlum:
			case HWMPPDB:
				databaseType = JdbcConstants.POSTGRESQL;
				break;
			case Hive:
				databaseType = JdbcConstants.HIVE;
				break;
		}
		return databaseType;
	}

}
