package cn.com.lgh.operation;



public abstract class AbstractOptionLog extends AbstractOptionUser{
    /**
    * @Description:    日志处理
    * @Author:         LGH
    * @CreateDate:     2019/5/23 10:30
    */
    public abstract String parseLog(String logContent,String format);
}
