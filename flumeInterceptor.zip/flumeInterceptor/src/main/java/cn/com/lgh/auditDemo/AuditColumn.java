package cn.com.lgh.auditDemo;
/**   
 * @Description: 审计表的列   
 * @Title:  AuditColumn.java   
 * @Package com.audaque.web.action
 * @author: huafu.su     
 * @date: 2019年3月18日 下午2:31:14   
 */
public class AuditColumn {
	
	private String table;//表名
	protected String  alias;//列的别名
	protected String shortName;//列名
	protected String fullName;//列全名
	
	public AuditColumn(){}
	
	public AuditColumn(String alias, String shortName, String fullName){
		this.alias = alias;
		this.shortName = shortName;
		this.fullName = fullName;
	}
	
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getFullName() {
		if (fullName == null) {
            if (table == null) {
                fullName = shortName;
            } else {
                fullName = table + '.' + shortName;
            }
        }
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}
	
}
