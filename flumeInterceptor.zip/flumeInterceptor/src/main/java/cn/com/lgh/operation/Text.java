package cn.com.lgh.operation;

public class Text  extends AbstractOptionLog  {
    @Override
    public String parseLog(String logContent,String format) {
        return "8324239";
    }
}
