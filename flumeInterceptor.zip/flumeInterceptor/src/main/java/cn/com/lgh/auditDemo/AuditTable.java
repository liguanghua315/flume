package cn.com.lgh.auditDemo;

import java.util.ArrayList;

/**   
 * @Description: 审计表   
 * @Title:  AuditTable.java   
 * @Package com.audaque.web.action
 * @author: huafu.su     
 * @date: 2019年3月18日 下午2:23:56   
 */
public class AuditTable {
	
	private String sqlType;//sql语句类型
	private String schema;//表的schema
	private String tableName;//表名
	private String fullName;//表全名
	private boolean allColumn;//是否所有列（true是，false否）;
	private ArrayList<AuditColumn> columns;
	
	public void addAuditColumn(AuditColumn column){
		if(this.columns == null){
			this.columns = new ArrayList<>();
		}
		this.columns.add(column);
	}
	
	public String getSchema() {
		return schema;
	}
	public void setSchema(String schema) {
		this.schema = schema;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public ArrayList<AuditColumn> getColumns() {
		return columns;
	}
	public void setColumns(ArrayList<AuditColumn> columns) {
		this.columns = columns;
	}

	public String getSqlType() {
		return sqlType;
	}

	public void setSqlType(String sqlType) {
		this.sqlType = sqlType;
	}

	public boolean isAllColumn() {
		return allColumn;
	}

	public void setAllColumn(boolean allColumn) {
		this.allColumn = allColumn;
	}

	
}
