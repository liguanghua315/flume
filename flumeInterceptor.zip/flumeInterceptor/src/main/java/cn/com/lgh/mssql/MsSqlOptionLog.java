package cn.com.lgh.mssql;

import cn.com.lgh.operation.AbstractOptionLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MsSqlOptionLog extends AbstractOptionLog {
    //打印日志，便于测试方法的执行顺序
    private static final Logger logger = LoggerFactory.getLogger(MsSqlOptionLog.class);
    @Override
    public String parseLog(String logContent,String format) {

        return "MSSQL";
    }
}
