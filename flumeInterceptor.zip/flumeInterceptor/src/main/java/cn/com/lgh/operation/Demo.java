package cn.com.lgh.operation;

import cn.com.lgh.mppdb.WMPPOptionLog;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Demo {

    public enum Status {

        GT(1," &gt; "), LT(1," &lt; "), EQ(2," = "), GTE(3," &gt;= "),LTE(1," &lt;= ");

        public Integer type;
        public String description;

        Status(Integer type,String description) {
            this.type = type;
            this.description = description;
        }

        public Integer getType() {
            return type;
        }

        public void setType(Integer type) {
            this.type = type;
        }

        public static String getDescription(Integer type) {
           for (Status status:Status.values()){
               if (type.equals(status.type)){
                   return status.description;
               }
           }
            return Status.LT.description;
        }


    }
    public static Date inittoday(){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.set(Calendar.HOUR, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return calendar.getTime();
    }
    private static Date getEndTime() {
        Calendar todayEnd = Calendar.getInstance();
        todayEnd.set(Calendar.HOUR_OF_DAY, 23);
        todayEnd.set(Calendar.MINUTE, 59);
        todayEnd.set(Calendar.SECOND, 59);
        todayEnd.set(Calendar.MILLISECOND, 999);
        return todayEnd.getTime();
    }

    public static void main(String args[]) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        System.out.println("1111111111"+Status.getDescription(1));
        System.out.println(sdf.format(DateUtils.addDays(inittoday(), 1)));;
        System.out.println(sdf.format(inittoday()));
        Calendar calendar1 = Calendar.getInstance();
        calendar1.add(Calendar.DATE, -1);
        System.out.println( sdf.format(calendar1.getTime()));
        AbstractOptionLog log=new WMPPOptionLog();
      //  System.out.println(log.parseLog("1234567","22"));
      //   System.out.println( JSONObject.toJSONString(pu("2019-03-18 10:56:18.038 CST 5c8f08d2.901 postgres 140421162317568 gsql 0 cn_5001 00000 28821087","%m&0-2 %c&3 %d&4 %p&5 %a&6 %x&7 %n&8 %e&9")));
      //  System.out.println( JSONObject.toJSONString(pu("postgres 2019-03-18 10:56:18.038 CST 5c8f08d2.901 140421162317568 gsql 0 cn_5001 00000 28821087","%d&0 %m&1-3 %c&4 %p&5 %a&6 %x&7 %n&8 %e&9")));
       // System.out.println( JSONObject.toJSONString(pu("5c8f08d2.901 postgres 140421162317568 gsql 0 cn_5001 00000 28821087","%c %d %p %a %x %n %e")));

        String s="2019-05-31 14:38:20 [DEBUG] org.activiti.engine.impl.persistence.entity.TaskEntity.selectTaskByQueryCriteria ==>  Preparing: select distinct RES.* from ACT_RU_TASK RES left join ACT_RU_IDENTITYLINK I on I.TASK_ID_ = RES.ID_ inner join ACT_RU_VARIABLE A0 on RES.PROC_INST_ID_ = A0.PROC_INST_ID_ inner join ACT_RE_PROCDEF D on RES.PROC_DEF_ID_ = D.ID_ WHERE D.KEY_ = ? and A0.TASK_ID_ is null and A0.NAME_= ? and A0.TYPE_ = ? and A0.LONG_ > ? and (RES.ASSIGNEE_ = ? or (RES.ASSIGNEE_ is null and I.TYPE_ = 'candidate' and (I.USER_ID_ = ? or I.GROUP_ID_ IN ( ? , ? , ? , ? , ? , ? , ? ) ))) order by RES.CREATE_TIME_ desc LIMIT ? OFFSET ? " +
                "";
        String s1="2019-05-31 14:38:20 [DEBUG] org.activiti.engine.impl.persistence.entity.TaskEntity.selectTaskByQueryCriteria ==> Parameters: issueAuditProcess(String), deadline(String), date(String), 1560096000000(Long), 10059(String), 10059(String), D_10080(String), D_10003(String), P_10031(String), P_10004(String), R_10000(String), T_1(String), T_6(String), 10(Integer), 0(Integer)" +
                "";
        String result=null;
        if (s.indexOf("Preparing:")>0&&s.split("Preparing:").length>1){
            result=s.split("Preparing:")[1];
            System.out.println(result+s1.split("Parameters:")[1].trim());
        }
        String ge="";
        if (s1.indexOf("Parameters:")>0&&StringUtils.isNotEmpty(s1.split("Parameters:")[1].trim())){
            ge=s1.split("Parameters:")[1];
            System.out.println(ge);
          String [] ar=  ge.split("\\),");
          for (int i=0;i<ar.length;i++){
              String t=ar[i];
              if (t.indexOf("String")>0||t.indexOf("Timestamp")>0){
                  ar[i] = "'"+ar[i].substring(0, t.lastIndexOf("(")).trim()+"'";
              }else{
                  ar[i] = ar[i].substring(0, t.lastIndexOf("(")).trim();
              }
          }
          for (String t:ar){
              System.out.println(t);
          }
            int count = 0;
            Pattern p = Pattern.compile("\\?");
            Matcher m = p.matcher(result);
            while (m.find()) {
                count++;
            }
            System.out.println(count);
           for (int i=0;i<count;i++){
               result=result.replaceFirst("\\?",ar[i]);
           }
            System.out.println(result);
        }

    }
    public static String  getValues(String data, String[] group,String[] valus){
          if (valus.length==1){
              return group[Integer.valueOf(valus[0])];
          }else{
             for (int i=Integer.valueOf(valus[0]);i<=Integer.valueOf(valus[1]);i++){
                 if (data==null){
                     data=group[i];
                 }else{
                     data=data+" "+group[i];
                 }
             }
             return data;
          }
    }
    public static Record pu(String content, String format){
        /**
         * 华为mpp日志格式  现在使用格式 %m %c %d %p %a %x %n %e，为保证日志格式的变动，这里做日志随着格式动态截取
         * log_line_prefix = '%t '   # Special values:
         *      #   %u = user name
         *      #   %d = database name
         *      #   %r = remote host and port
         *      #   %h = remote host
         *      #   %p = PID
         *      #   %t = timestamp (no milliseconds)
         *      #   %m = timestamp with milliseconds
         *      #   %i = command tag
         *      #   %c = session id
         *      #   %l = session line number
         *      #   %s = session start timestamp
         *      #   %x = transaction id
         *      #   %q = stop here in non-session
         *      #        processes
         *      #   %% = '%'
         *      # e.g. '<%u%%%d> '
         */
       Record record =new Record();
        String s1=content.split("STATEMENT:")[0];
        String[] group=s1.split(" ");
        String data=null;
        String session="";
        String db="";
        String pid="";
        String a_name="";
        String transactionId="";
        String n_name="";
        String e_name="";
        int md=0;
        if (StringUtils.isNotBlank(format)&&StringUtils.isNotBlank(content)){
            String [] formatList=format.split(" ");
            for (int f=0 ;f<formatList.length;f++){
                String fm=formatList[f];
                String[] bsf=fm.split("&");
                String fm1=bsf[0];
                String[] value=bsf[1].split("-");
                switch (fm1){
                    case "%m" : data=getValues(data,group,value)  ;break;
                    case "%c" :  session=getValues(session,group,value) ;break;
                    case "%d" :   db=getValues(db,group,value)  ;break;
                    case "%p" :  pid=getValues(pid,group,value);break;
                    case "%a" : a_name=getValues(a_name,group,value);break;
                    case "%x" :  transactionId=getValues(transactionId,group,value) ;break;
                    case "%n" :  n_name=getValues(n_name,group,value);break;
                    case "%e" : e_name=getValues(e_name,group,value)   ;break;
                }
            }
        }
        record.setData(data);
        record.setSession(session);
        record.setDb(db);
        record.setPid(pid);
        record.setA_name(a_name);
        record.setN_name(n_name);
        record.setTransactionId(transactionId);
        record.setE_name(e_name);

        return record;

    }


}
