package cn.com.lgh.interceptor;


import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import org.apache.flume.Context;
import org.apache.flume.Event;
import org.apache.flume.interceptor.Interceptor;

import java.text.SimpleDateFormat;
import java.util.List;


public class LogAnalysis implements Interceptor {

    private  String  sqlStatement=null ;
    private  Integer  status =0;
    public String getSqlStatement() {
        return sqlStatement;
    }

    public void setSqlStatement(String sqlStatement) {
        this.sqlStatement = sqlStatement;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    private LogAnalysis() {
    }

    @Override
    public void initialize() {
        // NO-OP...
    }

    @Override
    public void close() {
        // NO-OP...
    }
    public static void pu(String mes1){
        String s1=mes1.split("STATEMENT:")[0];
        String[] group=s1.split(" ");
        String data=null;
        String session="";
        String db="";
        String pid="";
        String a_name="";
        String transactionId="";
        String n_name="";
        String e_name="";
        for (int i=0;i<group.length;i++){
            if (i<3){
                if (data==null){
                    data=group[i];
                }else {
                    data=data+" "+group[i];
                }
            }
            if (i==3){
                session=group[i] ;
            }else  if (i==4){
                db=group[i] ;
            }else  if (i==5){
                pid=group[i] ;
            }else  if (i==6){
                a_name=group[i] ;
            }else  if (i==7){
                transactionId=group[i] ;
            }else  if (i==8){
                n_name=group[i] ;
            }else  if (i==9){
                e_name=group[i] ;
            }

        }
        System.out.println(data);
        System.out.println(session);
        System.out.println(db);
        System.out.println(pid);
        System.out.println(a_name);
        System.out.println(n_name);
        System.out.println(transactionId);
        System.out.println(e_name);
    }
    public static void sql1(String mes1){
        pu(mes1);
        System.out.println(mes1.split("STATEMENT:")[1]);
    }
    public static String sql4(String mes1){
        if (mes1.indexOf("SQL statement")>0){
            pu(mes1);
            mes1=mes1.split("SQL statement")[1];
        }
        return  mes1;
    }
    public static String sql5(String oldmes,String begainString,Integer status){
        if (status==1){
            return oldmes+" "+begainString;
        }else{
            return begainString;
        }
    }
    @Override
    public Event intercept(Event event) {

        /**event：
         * [{"body":'{"f_time":1515058629,"f_server_lan_address":"","f_server_wan_address":"101.37.75.140","f_params":{"f_dept":"2","f_character_grade":"20","f_server_address_id":"77","f_character_ip":"123.55.182.138","f_character_name":"横扫八荒","f_opt_type":"3","f_yuanbao_after":"205","f_channel":"9","f_sid":"77","f_yunying_id":"989c9961d30c5b76c79d2f9ba6410512","f_character_id":"77002097","f_yuanbao":"10"},"f_game_id":1,"f_log_name":"log_jinbi"}'}]
         */
        String body = new String(event.getBody(), Charsets.UTF_8);

       String begainString=body;
        if (begainString.indexOf("STATEMENT:")>0){
            sql1(begainString);
        }else   if (begainString.indexOf("CONTEXT:")>0){
            status=1;
            sqlStatement=  sql4(begainString);
        }else  if (begainString.indexOf("RETURN QUERY")>0){
            status=0;
            System.out.println(sqlStatement);
            sqlStatement=null;
        }else{
            sqlStatement=sql5(sqlStatement,begainString,status);

        }
        SimpleDateFormat timeFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String str = body.replaceAll("\\{|\\}", "");
        StringBuffer bodymid = new StringBuffer();
        String[] list1 = str.split(",");
        /**
         * f_time是PHP时间戳（9位），加三个0可以转换为时间
         */
        String f_time = list1[0].split(":")[1];
        long l = Long.parseLong(f_time + "000");
        String time = timeFormater.format(l);
        for (String str1 : list1) {
            String[] list = str1.split(":");
            bodymid.append("|" + list[1].replace("\"", ""));
        }
        String bodyoutput = bodymid.toString().replace(f_time, time).substring(1);
        event.setBody(bodyoutput.getBytes());
        return event;
    }

    @Override
    public List<Event> intercept(List<Event> events) {
        List<Event> intercepted = Lists.newArrayListWithCapacity(events.size());
        for (Event event : events) {
            Event interceptedEvent = intercept(event);
            if (interceptedEvent != null) {
                intercepted.add(interceptedEvent);
            }
        }
        return intercepted;
    }

    public static class Builder implements Interceptor.Builder {
        //使用Builder初始化Interceptor
        @Override
        public Interceptor build() {
            return new LogAnalysis();
        }

        @Override
        public void configure(Context context) {

        }
    }
}
